﻿namespace SimpleObserver
{
    class Event { }
}
