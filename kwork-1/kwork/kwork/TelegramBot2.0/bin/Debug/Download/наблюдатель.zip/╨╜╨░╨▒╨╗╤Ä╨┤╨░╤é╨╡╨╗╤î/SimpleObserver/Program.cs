﻿using System.Linq;

namespace SimpleObserver
{

    class Program
    {
        static void Main(string[] args)
        {
            Observer tt = new Observer();
        }
    }
}
