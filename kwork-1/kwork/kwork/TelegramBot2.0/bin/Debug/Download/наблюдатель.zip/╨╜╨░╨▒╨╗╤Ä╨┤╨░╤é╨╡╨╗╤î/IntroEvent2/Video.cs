﻿namespace IntroEvent2
{
    class Video : MediaFile
    {
        public Video(string fileName) : base(fileName) { }
    }
}
