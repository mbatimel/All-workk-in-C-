﻿using System;


namespace IntroEvent3
{

    class Program
    {
        static void Main(string[] args)
        {
            TikTokUser user1 = new() { Nick = "user_1" };
            TikTokUser user2 = new() { Nick = "user_2" };
            TikTokUser user3 = new() { Nick = "user_3" };
            TikTokUser user4 = new() { Nick = "user_4" };
            TikTokUser user5 = new() { Nick = "user_5" };

            user1.VideoPublishing(new MediaFile("Полезная мысль #1"));
            user1.Followers += user1.Alert;
            user1.Followers += user3.Alert;
            user1.Followers += user4.Alert;
            user1.Followers += user5.Alert;

            user1.VideoPublishing(new MediaFile("Полезная мысль #2"));
            user1.VideoPublishing(new MediaFile("Полезная мысль #3"));

            Console.WriteLine();
            user2.Followers += user2.Alert;
            user2.VideoPublishing(new MediaFile("Полезная история #1"));

            Console.ReadLine();
        }
    }
    class Account
    {
        public string Nick { get; set; }
    }
   
    class MediaFile
    {
        public MediaFile(string fileName) => FileName = fileName;
        public string FileName { get; set; }
    }
    class TikTokUser : Account
    {
        private Action<TikTokUser, string> followers;
        public event Action<TikTokUser, string> Followers
        {
            //add => followers += value;
            //remove => followers -= value;

          
        
            add
            {
                Console.WriteLine($"{(value.Target as Account).Nick} подписался на {this.Nick}");
                followers += value;
            }
            remove
            {
                Console.WriteLine($"{(value.Target as Account).Nick} отказался от подписки на {this.Nick}");
                followers -= value;
            }

          
        }

        public void Alert(TikTokUser sender, string info)
        {
            if (sender != this) Console.WriteLine($"Лента {this.Nick}: У {sender.Nick} {info}");
            else Console.WriteLine($"У меня({this.Nick}) {info}");
        }

        public void VideoPublishing(MediaFile media)
        {
            //var fn = media.FileName;
            var fn = $"вышло видео '{media.FileName}'";
            Alert(this, fn);
            if (followers != null) followers(this, fn);
        }
    }
    class Video : MediaFile
    {
        public Video(string fileName) : base(fileName) { }
    }
}
