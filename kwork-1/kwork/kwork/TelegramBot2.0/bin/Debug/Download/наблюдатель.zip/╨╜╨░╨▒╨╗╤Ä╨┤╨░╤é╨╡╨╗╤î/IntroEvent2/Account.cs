﻿namespace IntroEvent2
{
    class Account
    {
        public string Nick { get; set; }
    }
}
