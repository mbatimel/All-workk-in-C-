﻿namespace UniversityObserver
{
    interface IPropertyObserver
    {
        void SpeechTo(string text);
    }
}