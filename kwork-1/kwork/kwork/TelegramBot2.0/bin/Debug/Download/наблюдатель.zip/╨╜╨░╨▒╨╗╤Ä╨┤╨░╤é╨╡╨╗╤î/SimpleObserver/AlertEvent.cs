﻿namespace SimpleObserver
{
    class AlertEvent : Event { }
}
