﻿namespace IntroEvent2
{
    class MediaFile
    {
        public MediaFile(string fileName) => FileName = fileName;
        public string FileName { get; set; }
    }
}
