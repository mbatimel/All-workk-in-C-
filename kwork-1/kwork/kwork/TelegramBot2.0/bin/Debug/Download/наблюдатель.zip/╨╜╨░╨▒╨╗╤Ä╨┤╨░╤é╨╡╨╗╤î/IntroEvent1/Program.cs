﻿using System;
using static System.Console;

namespace IntroEvent1
{

    class Program
    {
        static void Main(string[] args)
        {
            // Видео https://youtu.be/8UUO81WB_5M

            TikTokUser user1 = new() { Nick = "user_1"};
            TikTokUser user2 = new() { Nick = "user_2" };

            user1.VideoPublishing(new MediaFile("Полезная мысль #1"));
            user1.Subscribe(user2);

            user1.VideoPublishing(new MediaFile("Полезная мысль #2"));
            user1.VideoPublishing(new MediaFile("Полезная мысль #3"));

            WriteLine();
            user2.Subscribe(user1);
            user2.VideoPublishing(new MediaFile("Полезная история #1"));
            user2.Unsubscribe(user1);

            ReadLine();
        }
    }
    //class Account
    //{
    //    public string Nick { get; set; }
   // }
    // Есть сущность порождающая события
    // Есть сущности, которые хотят получать уведомления об этих событиях
    class MediaFile
    {
        public MediaFile(string fileName) => FileName = fileName;
        public string FileName { get; set; }
       
    }
    class TikTokUser //: Account
    {
        public string Nick { get; set; }
        protected Action<TikTokUser, string> followers;
        public void Subscribe(TikTokUser user)
        {
            WriteLine($"{user.Nick} подписался на {this.Nick}");
            followers += user.Alert;
        }
        public void Unsubscribe(TikTokUser user)
        {
            WriteLine($"{user.Nick} отказался от подписки на {this.Nick}");
            followers -= user.Alert;
        }
        public void Alert(TikTokUser sender, string info)
        {
            if (sender != this) WriteLine($"Лента {this.Nick}: У {sender.Nick} {info}");
            else WriteLine($"У меня({this.Nick}) {info}");
        }
        public void VideoPublishing(MediaFile media)
        {
            //var fn = media.FileName;
            var fn = $"вышло видео '{media.FileName}'";
            Alert(this, fn);
            //if (followers != null) followers(this, fn);
            followers?.Invoke(this, fn);

        }
    }
  
}
