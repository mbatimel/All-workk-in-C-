﻿namespace SimpleObserver
{
    class LoggerEvent : Event { }
}
